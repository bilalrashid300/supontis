import React, {useState} from 'react'
import logo from '../../assets/Logo.svg'
import {FaBars, FaTimes} from 'react-icons/fa'
import './navbar.css'



const Navbar = () => {
    const [click, setClick] = useState(false)
    const handleClick = () => setClick(!click)
    return (
        <div className='header'>
            <div className='container'>
                <div>
                    <img src={logo}  alt='logo'  className='logo'/>    
                </div>
                <ul className={click ? 'nav-menu active' : 'nav-menu'}>
                    <li>
                        <a href='/'>Home</a>
                    </li>
                    <li>
                        <a href='/'>What we offer</a>
                    </li>
                    <li>
                        <a href='/'>About</a>  
                    </li>
                    <li>
                        <a href='/'>The Smartphone Boom</a>
                    </li>
                    <li>
                        <a href='/'>Roadmap</a>
                    </li>
                    <li>
                        <a href='/'>Tokenomics</a>
                    </li>
                    <li>
                        <a href='/'>FAQs</a>
                    </li>
                   
                </ul>
                <div className='hamburger' onClick={handleClick}>
                    {click ? (<FaTimes className='centreham' size={20} style={{color: 'white'}}/>) : (<FaBars size={24} style={{color: 'black'}} />)}
                </div>
            </div>
        </div>
    )
}

export default Navbar
